#  E01. 간단히 만들어보는 웹페이지 | S01. HTML+CSS 입문 | 미운 웹 백조만들기

## 동영상 강의 바로가기
[구름EDU | 미운 웹 백조 만들기](https://edu.goorm.io/learn/lecture/16783/%EB%AF%B8%EC%9A%B4-%EC%9B%B9-%EB%B0%B1%EC%A1%B0-%EB%A7%8C%EB%93%A4%EA%B8%B0-html-css)

## 구름IDE Container
[구름IDE Container Link](https://goor.me/E5efv)

## Git Repository
[https://github.com/develup-official/htmlcss-s01e01](https://github.com/develup-official/htmlcss-s01e01)

## 알아보는 개념
- HTML과 CSS는 무엇인가?
- CSS 디자인의 기본, BoxModel
- 크롬의 "검사" 기능 활용
- 브라우저 기본스타일


